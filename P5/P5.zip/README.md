# Usuarios registrados

**Usuario** ->**contraseña**

superman->metropolis

noSpiderMan -> araña

caballero_oscuro -> murcielago